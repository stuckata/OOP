package shapes;

public interface Movable {
	public void move(double deltaX, double deltaY);
}
