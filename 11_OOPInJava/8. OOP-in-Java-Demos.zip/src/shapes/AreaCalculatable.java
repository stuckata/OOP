package shapes;

public interface AreaCalculatable {
	public double calculateArea();
}
