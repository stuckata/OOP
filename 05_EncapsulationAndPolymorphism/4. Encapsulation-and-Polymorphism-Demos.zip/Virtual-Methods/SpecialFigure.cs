﻿using System;

class SpecialFigure : Figure
{
}
