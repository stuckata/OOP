﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02_BankOfKurtovoKonare.Interfaces
{
    interface IDeposit
    {
        decimal DepositMoney(decimal deposit);
    }
}
