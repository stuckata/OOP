﻿using ConsoleForum.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleForum.Entities.Posts
{
    public class Answer : Post
    {
        public Answer(int id, IUser author, string body)
            : base (id, author, body)
        {
        }
    }
}
