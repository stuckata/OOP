﻿using ConsoleForum.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleForum.Entities.Posts
{
    public class Question : Post, IQuestion
    {
        private string title;
        private IList<IAnswer> answers;

        public Question(int id, IUser author, string body, string title)
            : base(id, author, body)
        {
            this.Title = title;
        }

        public IList<IAnswer> Answers
        {
            get
            {
                return this.answers;
            }
        }

        public string Title
        {
            get
            {
               return this.title;
            }
            set
            {
                this.title = value;
            }
        }
    }
}
