﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_CompanyHierarchy.Enumerations
{
    class DepartmentType
    {
        public enum Department
        {
            Production, 
            Accounting, 
            Sales,
            Marketing
        };
    }
}
