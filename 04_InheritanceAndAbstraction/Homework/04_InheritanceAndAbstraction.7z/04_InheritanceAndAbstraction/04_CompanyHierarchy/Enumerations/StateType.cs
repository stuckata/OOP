﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_CompanyHierarchy.Enumerations
{
    class StateType
    {
        public enum State
        {
            Open,
            Closed
        };
    }
}
