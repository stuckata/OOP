﻿public interface IMovable
{
    void Move(int deltaX, int deltaY);
}
