﻿public interface IShape
{
    void SetPosition(int x, int y);
    double CalculateSurface();
}
