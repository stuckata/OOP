﻿public interface IClickable
{
    event ClickEventHandler Click;
}