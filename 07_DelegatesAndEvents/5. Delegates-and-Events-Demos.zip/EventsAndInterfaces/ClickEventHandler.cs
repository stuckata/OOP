﻿using System;

public delegate void ClickEventHandler(object sender, EventArgs eventArgs);
