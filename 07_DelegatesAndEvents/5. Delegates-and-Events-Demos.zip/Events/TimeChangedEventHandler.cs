﻿public delegate void TimeChangedEventHandler(object sender, TimeChangedEventArgs eventArgs);
