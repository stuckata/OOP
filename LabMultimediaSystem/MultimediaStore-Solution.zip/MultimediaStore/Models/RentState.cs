﻿namespace MultimediaShop.Models
{
    public enum RentState
    {
        Pending,
        Overdue,
        Returned
    }
}
