﻿namespace MultimediaShop.Models.Items
{
    public enum AgeRestriction
    {
        Minor,
        Teen,
        Adult
    }
}
