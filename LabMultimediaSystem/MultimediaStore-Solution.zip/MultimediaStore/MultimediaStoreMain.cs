﻿namespace MultimediaShop
{
    using MultimediaShop.Core;

    public class MultimediaStoreMain
    {
        public static void Main()
        {
            var storeEngine = new StoreEngine();
            storeEngine.Run();
        }
    }
}
