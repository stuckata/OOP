<?php

namespace Shapes\Data;

interface iMovable
{
    function move($deltaX, $deltaY);
}
