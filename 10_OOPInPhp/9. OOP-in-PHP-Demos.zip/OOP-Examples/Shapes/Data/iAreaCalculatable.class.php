<?php

namespace Shapes\Data;

interface iAreaCalculatable {
    function calcArea();
}