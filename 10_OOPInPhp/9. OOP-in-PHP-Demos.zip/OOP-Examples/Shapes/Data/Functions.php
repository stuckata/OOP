<?php

namespace Shapes\Data;

function printMyName() {
    echo "I am Nakov\r\n";
}
