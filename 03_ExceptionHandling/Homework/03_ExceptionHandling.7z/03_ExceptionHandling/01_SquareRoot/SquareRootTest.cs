﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_SquareRoot
{
    class SquareRootTest
    {
        static void Main(string[] args)
        {
            SquareRoot number = new SquareRoot("4");
            Console.WriteLine(number);
        }
    }
}
