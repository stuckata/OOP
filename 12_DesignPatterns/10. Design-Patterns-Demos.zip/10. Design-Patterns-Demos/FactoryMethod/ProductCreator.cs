﻿namespace FactoryMethod
{
    public abstract class ProductCreator
    {
        public abstract Product CreateProduct();
    }
}
