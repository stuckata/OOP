﻿namespace FactoryMethod
{
    public class Chair : Product
    {
        public Chair(string description)
            : base(description)
        {
        }
    }
}
