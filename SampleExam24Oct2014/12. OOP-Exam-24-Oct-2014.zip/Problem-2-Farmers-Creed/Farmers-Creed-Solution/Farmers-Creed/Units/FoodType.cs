﻿namespace FarmersCreed.Units
{
    public enum FoodType
    {
        Meat = 1,
        Organic = 2
    }
}
