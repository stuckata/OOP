﻿namespace FarmersCreed.Units
{
    using System;

    public enum FoodType
    {
        Organic
    }
}
