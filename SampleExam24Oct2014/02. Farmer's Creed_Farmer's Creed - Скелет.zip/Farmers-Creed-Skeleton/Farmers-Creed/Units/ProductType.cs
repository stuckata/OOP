﻿namespace FarmersCreed.Units
{
    public enum ProductType
    {
        Grain
    }
}
